*==============================================================*
* TeamFortress v1.32								readme.txt *
*==============================================================*
Introduction
------------

TeamFortress is a new QuakeC patch which radically changes
team games. It provides far more incentive for teams to 
actually work as a team. Each member of the team has unique
weapons, items, and abilities.

It is most fun to play on a map with two, or more, clearly defined
team fortresses, or bases. If you don't have any of our TeamFortress
Maps, try some of quake's levels. Define the team areas, and a goal 
or two. For example, we sometimes play on e1m1. Its not a big map, so 
we play with two teams of 4. One team's base is the room containing
the end of level slipgate. The other team starts at the bridge
outside, and has to finish the level. The first team has to
prevent the other team from finishing the level.

Once you have some clear goals like this, and start using the 
individual class's abilities to complement each other, it's a hell
of a lot of fun!

At the moment, we've got one FortressMap almost finished. As we, or 
you :), make more maps for this patch, we'll put them up on the 
WWW page (see Availability).
If you're interested in making maps to use the extra features
of this patch, see the TeamFortress Map Details below, and the
tfortmap.txt file inside this .zip file.

Also, Why don't we include a diff/patch file with the source
for this mod? Simply because the amount of changes in this patch
make it unfeasible. Almost all large sections of new code are in
seperate files, but large sections of the original code have been
rewritten/removed extensively, making it very hard to combine
with other patches, even with diff/patch. Sorry Jeff! ;)
If there is demand for it, I may 'clip' the Goal Map entity handling
out and put it in it's own patch, so it can be used with other
patches. If you would like this, mail me and say so, or it won't
get done :)

What do you need to know?
-----------------------
Really, if you want to get into TeamFortress as soon as possible, 
all you need to know is the command "helpme". Type this in at the
console and you'll be shown the help index.
You should be able to figure it out from there :)

_NOTE_: The aliases created for you, such as helpme, do _not_
		work in a single-player game if you type them into the
		console. Instead, you _must_ bind a key to them, get out
		of the console, and press the key.
		e.g. In the console, type "bind h helpme" and then
			 get out of the console and press your h key.
		If you're interested in why you have to do this, see
		the Impulse and Alias summaries below.
		Although this is a pain, it's worth it. Trust me! ;)

Player Classes
--------------
TeamFortress uses multiple player classes. Whenever a new map is loaded,
all players start in Observer mode. 
When in Observer Mode, players can use there fire button to cycle
through all the observation points on a map, and watch the action.
To get out of Observer Mode, players must choose a class.
To choose a class, just use the appropriate alias. Once a player class 
is chosen, you cannot change class for the rest of that level. 
The classes implemented so far are as follows:
	SCOUT:		Fastest moving class. Can only wear a small amount of the 
				lowest absorption armor. Limited to the 2 Shotguns and Nailgun.
				Low ammo levels.
				Carries a Motion Detector, 3 flares, 2 concussion grenades.

	SNIPER:		Medium speed. Wears only small amount of armor, upto medium
				absorption level. Limited to Nailgun and Sniper's rifle. Medium
				ammo levels.
				Carries 2 hand grenades.

	SOLDIER:	Slow moving class. Wears large amount of armor, at all 
				absorption levels. All normal weapons except Grenade Launcher.
				High ammo levels.
				Carries 4 hand grenades, 4 nail grenades.

	DEMOLITION MAN: Medium speed. Wears medium amount of armor, upto medium
				absorption level. Uses the ShotGun and Grenade/Pipebomb Launcher
				Carries 1 DetPack, 6 hand grenades, 4 Mirv Grenades.

	COMBAT MEDIC: Medium speed. Wears medium amount of armor, upto medium
				absorption level. Uses both Shotguns and the Super Nailgun.
				Carries Medikit, 3 hand grenades, 1 concussion grenades.
				Regenerates slowly. Has a Bioweapon.

	HEAVY WEAPONS GUY: The slowest moving class of all. Lotsa armor, high
				absorption levels. Uses both Shotguns, the Nailgun, and
				the Assault Cannon (yeah!)
				Carries 4 hand grenades and 1 Mirv Grenade.

	PYRO:		Medium speed. Wears some flame-resistant armor.  Uses the 
				shotgun, flamethrower, and incendiary cannon. 
				Carriers 1 hand grenade and 4 Napalm grenades.

	RANDOM CLASS: Each time you respawn you have your class randomly 
				  assigned to you.

New Weapons
-----------
Please note that the New Weapons do not show up on the row of weapon
icons in the status bar. There is a reason for this. At first, we used
to light up the weapon icon corresponding to the number of the New Weapon.
For example, the Heavy Weapons Guy has the Assault Cannon, and can select
it by pressing 7. So we lit up the Rocket Launcher icon. We immediately
got lots of mail from people saying "I can't get the rocket launcher
readied when I'm the Heavy Weapons Guy!".
So we don't light them up.

Sniper Rifle:
	This weapon is used instead of the shotgun by the SNIPER playerclass. It
	uses shotgun shells for ammo, and operates in two modes:
		- Single Shot. With a reload time of 2.5 seconds, this mode is what
		  sniping is all about. One shot from this will kill most players
		  except for a heavily armored SOLDIER or DEMOLITION MAN.
		  The longer you aim, the more damage the sniper shot will do.
		  To aim, just keep holding down the fire button. 
		  When aiming, the view slowly zooms in. You can disable this
		  feature using the "autozoom" command.
		- Auto Shot. Although this fire mode does a lot less damage than
		  single shot and uses a lot of ammo, its great for picking off
		  a wounded target, or a fast moving SCOUT.
	The other tricky bit about the sniper rifle is that it is a rifle. You
	can't just snap shot from the hip with it. If you're moving too fast,
	the rifle simply won't fire. Besides, you're a sniper, you're not
	supposed to be strafe-fighting with soldiers! :)
	Select it as if it was the shotgun.

Assault Cannon:
	Big! Fires lotsa bullets! Really fast!
	What more do you want?
	It's used by the Heavy Weapons Guy. Select it like you would the
	Rocket Launcher. It takes 10 cells just to power up	each time you 
	pull the trigger, and then starts to eat up your shotgun ammo like 
	you wouldn't believe!
	It also tends to eat up enemies too, so it isn't all bad :)
	As you fire the Assault Cannon, it gets hotter and harder to control. 
	After firing, it has to cool. This can take a while, and is dependant 
	on how long you fired it for, natch :)
	Luckily, cooling require no effort on your part, so you can change
	weapons while you wait.
	Oh, you can't move while firing either, and you can't fire when
	you're not on the ground.
	Select it as if it was the rocket launcher.

BioWeapon:
	This weapon is used by the COMBAT MEDIC. The COMBAT MEDIC's axe has two
	modes: Medikit and BioWeapon. In Bioweapon Mode, when the COMBAT MEDIC
	hits someone with the axe, they will become infected, and begin to lose
	health. Anyone coming in contact with an infected person also becomes
	infected. Infection can be cured by the COMBAT MEDIC's medikit.
	COMBAT MEDICS are immune to the Bioweapon.

Incendiary Cannon:
	This weapon is used in place of the rocket launcher by the PYRO class.
	It does a little damage, and sets everyone in radius on fire. 
	Select it as if it was the rocket launcher.

Grenades
--------
Several new types of grenades now exist, and all classes have access to at
least one of them. They are not to be confused with the grenades used by
the grenade launcher.
Use of these grenades is exactly as one would expect. Pull the pin, throw
it, and wait. After 3 seconds it goes off. Just make sure you throw it
_before_ the 3 seconds are up :)
The grenade types are as follows:
	Hand		:	Hand grenades simply explode. They are twice as powerful
					as those shot from the grenade launcher.

	Concussion	:	Concussion grenades don't actually hurt anyone, they just
					blow everyone away from the grenade explosion at a high
					speed, and then make them woozy. They're the SCOUT's best 
					way of escaping from a roomful of enemies. The ensuing confusion 
					usually gives him enough time to run.

	Nail		:	Nail grenades are good in large rooms. Instead of detonating,
					they raise up into the air and hover. They then begin to 
					rotate while firing nails. After doing this for a few seconds
					they explode like a normal grenade.

	Mirv		:	Mirv grenades are room-clearers. When one explodes,
					it divides into approximately 15 individual grenades which
					then explode.

	Napalm		:	When these explode they throw flames out in all directions,
					setting things, like players, alight.

New Items
---------
Motion Detector:
	This item is the SCOUT's best friend. The SCOUT can specify an amount of
	cells spent on a scan. The detector displays a list of all enemies/friends
	within a distance around the SCOUT, and their direction in relation to the 
	SCOUT. The more energy spent, the larger the detection distance.
	Bear in mind though that the motion detector only detects motion (natch! :)
	So it won't pick up stationary or very slow moving players.
	You can toggle detection of friends and enemies using the aliases "scane" and "scanf"
	or impulse 1 and 2 after the Pre-Impulse. For more information on 
	Pre-Impulses, see the Impulse Summary.

Medikit:
	The COMBAT MEDIC has a medikit which allows him to heal any other member
	of his/her team by hitting them with his axe, when it is in Medikit Mode. 
	Each hit will heal them	10 points and reduce the 'ammo' for the medikit 
	by 10. You can see how much 'ammo' for the medikit you have by looking 
	at your inventory. If the COMBAT MEDIC walks over a health box while at 
	maximum health, the health box will be used to replenish the medikit 'ammo'.

Detpack:
	The DEMOLITION MAN has a Detpack. This is a large-scale explosive device.
	When the DEMOLITION MAN places it he is unable to move for 4 seconds
	while he primes it.
	The timer on the Detpack is set by the DEMOLITION MAN. e.g. After the 
	Pre-Impulse, an Impulse of 10 sets the timer for 10 seconds. For more 
	information on Pre-Impulses, see the Impulse Summary.
	Oh yeah, Scouts can disarm them by running over them :)

New Rules
---------
Reloading:
	All basic weapons except the Nailgun and Super Nailgun have clips. When all
	the ammo in a clip is spent, the weapon is reloaded. This can take anywhere
	from 1 second for the Shotgun to 5 seconds for the Rocket Launcher. Ammo
	amounts in the clips varies between weapons.
	While reloading, you cannot change weapons.

Armor Classes:
	There are various classes of armor now, which protect against various
	different attack types. Each playerclass is restricted to using only
	certain types. 
	You can find out what class of armor you're wearing using the Inventory
	command. When you pick up armor, the message displayed will tell you
	what armor class it is, if any.

ToggleAble Game Settings
------------------------
There are now a few toggleable game settings which can be changed while
playing. Each has an alias which toggles it.
The options at the moment are:
	Multiskin/Classkin
		This option switches between Multiskin, where each player can use the 
		skin commands to cycle through all the available skins and choose one
		they like, and Classkin, where each player has his/her skin chosen
		for them based on their class.
	Class Persistence On/Off
		This option allows you to turn on Class persistence between levels.
		E.g. If it's on, when you go to a new level each player will stay
		the same class they were in the last level.
	Cheat Checking On/Off
		This option toggles whether you want speed checking of players in
		an attempt to catch people tinkering with their maxspeed. It's not
		an elegant way of checking, and is by no mean foolproof, so you
		may wish to turn it off. If you're playing with friends, turn it off
		and save some of the server's computing time. If you're playing on 
		the net, you might want to leave it on. It's better than nothing :)
	FortressMap On/Off
		This option turns on the use of effects which only work on maps
		built specifically for TeamFortress. I'd advise against turning 
		it on in maps that aren't built for TeamFortress. 
		If you play on a TeamFortress Map, TeamFortress will detect this,
		and set this setting On, but you're welcome to turn it off if
		you want to deathmatch. 
		See TeamFortressMap Details below for more info.
	AutoTeam On/Off
		When on, AutoTeam will automatically assign players to the team
		with the least number of people in it, when the player chooses
		his/her class.
	Respawn Delay Cycle
		You can cycle through various respawn delay times. Respawn
		delay time is the amount of time a player is unable to respawn
		for after they die.
		This is useful in Team Games to prevent players from killing
		themselves to get back to their Fortress quickly.
	TeamFrags On/Off
		When On, this toggleflag makes each player's frag count equal
		to the number of points his/her team has. Using TAB key you can
		then see how each team is going.
	Server Toggle
		This toggleflag has one use: When it's set, no toggleflags can
		ever been changed again. This can be used by a server operator
		to set the state of the toggleflags and then lock them in place.

Alias Summary
--------------
Aliases are fine and dandy, but there's just one small problem with them :)
If you're playing a single-player game, aliases that use a Pre-Impulse, such
as all the Help, Scanner, Detpack, and Setskin aliases, don't work if you
type them in at the console.
If you're playing a single-player game, you'll have to bind them to a key,
get out of the console, and press the key. It's a bummer, but hey!, this 
patch is for team games :)
And Pre-Impulses are too good to remove because of it.
The aliases that are automatically created for you by TeamFortress are:

Help Related
	helpme			:	Display Help Index
	generalhelp		:	Display General command help
	classhelp		:	Display Class command help
	weaponhelp		:	Display Weapon command help
	itemhelp		:	Display Item command help
	skinhelp		:	Display Skin command help
	teamhelp		:	Display Team command help
	togglehelp		:	Display Toggleflag command help
	preimphelp		:	Display Pre-Impulse help 
	showpreimp		:	Display a list of the Pre-Impulses used
	showimp			:	DIsplay a list of the Impulses used

General
	inv				:	Display your inventory
	showtf			:	Display the status of all Toggleflags

Class Changing
	scout			:	Change class to Scout
	sniper			:	Change class to Sniper
	soldier			:	Change class to Soldier
	demoman			:	Change class to Demolitions Man
	medic			:	Change class to Combat Medic
	hwguy			:	Change class to Heavy Weapons Guy
	pyro			:	Change class to Pyro
	randompc		:	Change class to Random Class

Grenades
	primeone		:	Prime a grenade of Type 1
	primetwo		:	Prime a grenade of Type 2
	throwgren		:	Throw whatever grenade you've primed

Pipebombs
	detpipe			:	Detonate all your pipebombs

Scanner
	scane			:	Toggle detection of enemies with the Scanner
	scanf			:	Toggle detection of friendlies with the Scanner

Sample aliases for the Scanner
	scan10			:	Scan using 10 cells
	scan50			:	Scan using 50 cells
	scan250			:	Scan using 250 cells

Sample aliases for the Detpack
	det5			:	Set your detpack for 5 seconds
	det20			:	Set your detpack for 20 seconds
	det250			:	Set your detpack for 250 seconds

Toggleable Game Settings
	t_skin			:	Toggle Multiskin/Classkin
	t_classpersist	:	Toggle Class Persistence
	t_cheatcheck	:	Toggle Cheat Checking
	t_fortressmap	:	Toggle FortressMap
	t_autoteam		:	Toggle Auto-Teaming
	t_respawndelay	:	Toggle RespawnDelays
	t_teamfrags		:	Toggle TeamFrags
	t_notoggle		:	Toggle Server-Only Toggleflags

Skin Selection
	nextskin		:	Change skin to the next skin in the player.mdl 
	prevskin		:	Change skin to the previous skin in the player.mdl 

Sample aliases for Set Skin
	skin10			:	Change skin to number 10 in the player.mdl
	skin20			:	Change skin to number 20 in the player.mdl

Team Handling
	imin1			:	Start/Join Team 1
	imin2			:	Start/Join Team 2
	imin3			:	Start/Join Team 3
	imin4			:	Start/Join Team 4
	showscores		:	Display Team Scores
	showclasses		:	Display the Classes of your Team Members

The sample aliases are examples of how the Pre-Impulses commands are used.
For more information on Pre-Impulses and how to create your own aliases for
Scanner/Detpack/Setskin etc, see the Impulse Summary.

Impulse Summary
---------------
In version 1.0 everything relied on Impulses. Now, it's all bound to aliases.
This means you don't have to know the impulses unless you want to merge this
with another patch, in which case you can look at the code, or type "showimp"
in the console.
The only thing I should mention is Pre-Impulses. A Pre-Impulse is an impulse
which must be used before another impulse. The second impulse can then be
interpreted in a different way.
For example:
	The SCOUT's Motion Detector has a Pre-Impulse of 249. You specify the 
	amount of energy you want to spend on the scan with an impulse after it.
	So if you wanted to use 50 energy to scan, you would do Impulse 249
	followed by Impulse 50. The recommended way to do this is to bind
	a key to an alias. In the console, you could do this:
		alias scan_50 "impulse 249; wait; impulse 50"
		bind S scan_50
	This would make 'S' do a scan using 50 energy.
There are already aliases created for all Pre-Impulse things, but you might 
to make your own, for different time/energy usages.
You will probably want to make an alias to set your favourite skin when 
playing Multiskin, so you don't have to use nextskin 14 times if you
like skin 15. Create an alias which does the Multiskin Pre-Impulse(202), and 
then does the Impulse matching the skin you want, e.g. 15.

Team Details
-----------------------
We now handle a basic Team structure. Apart from standard Teamplay,
you can use FortressTeams. In FortressTeams we allow upto 4 different
teams on the one map.
Players can join a team by using the aliases imin1,imin2,imin3, and imin4.
The first player to join a particular team becomes the Team Leader, and
the color of his/her pants becomes the Team Color. Any players who
join that Team from then on will have their colors automatically changed
to the Team Colors.
Once players join a team they cannot change to another team.
Any player who attempts to change their _pants_ color away from the
Team Color will be penalised. Shirt colors can be changed freely.
FortressTeams are a must on any Map that was written for TeamFortress,
since the spawnpoints on a TeamFortress Map are allocated to particular
teams. See the TeamFortressMap Details for more info.
Now, when you join a team, you are also shown the classes that your
team members are playing as. You can also use the command "showclasses"
to see what class they are at any particular time. Very useful if your
team members are playing RandomPC.

TeamFortressMap Details
-----------------------
As of v1.2 we've got support built in for maps designed specifically
for this patch, allowing them to use various extra entities.
This allows us to do fancy things, such as:

	Auto Detection
	Team SpawnPoints
	Armor 			

	Goals
	GoalItems
	Timer Goals

These only come into effect if the Toggleable game setting FortressMap is On,
and the map you are playing on is designed for TeamFortress.
If you want to create your own Maps for TeamFortress, the details you
need to know are in a separate file, included in this .zip, called tfortmap.txt

Multiskin Details
-----------------
We now have support for skins in TeamFortress. There are two modes:
Multiskin and Classkin, which is the default. With Classkin, your 
skin is set to a skin based on your Class, and you cannot change it.
Multiskin works the same way as the Original Multiskin by Dennis
Noordsij. For now, all skins we use are skins which come with Multiskin,
but we've got a couple of people drawing skins right now, and when
they're done, we'll give them to Dennis to include in Multiskin.
If you download a newer version of Multiskin that has more skins
in it, you will have to edit defs.qc. Right near the end of the
file is line like this:
	float MS_MAX_SKIN	= 32;
Change the 32 to the number of skins in the new player.mdl.
The latest version of Multiskin's player.mdl can always be
found at http://www.inter.NL.net/users/L.J.Noordsij/qc.htm

We now have skins for all the classes. (Yay!)
So you may just wish to stay in Classkin mode.

Servers with this Code
----------------------
If you're interested in using some/all of this code for a Net server, 
then all I ask is one thing: Mail me (address below) and tell me. 
I'd like to know if anyone uses it as a Net server, simply because I'd like 
to play a server on the net using this code. 
Since I don't have a server...;)
The biggest advantage of notifying me that you're running a server
with this code is that I'll mail you new versions whenever they come out.

Also you may wish the edit the defs.qc file and change the value of
the last line, which looks like this:
	float IS_NET_SERVER	= 0;
Change the 0 to a 1, and recompile the code. Now, TeamFortress will
only use graphics/sounds that come with quake, so people connecting to
your server won't need any extra files.
Of course, it won't sound/look half as good... :)

Copyright and Distribution
--------------------------------------
Authors may use this code for the basis of other freeware quakec
code, but not for any for-profit code, such as modification of this 
patch for the purpose of running it on a commercial Quake Server.

You may distribute this patch in any electronic format as long as this 
textfile remains unmodified and all of the files in the archive are
present, and as long as no charge is made for it.

Non-Commercial Quake Servers are free to run this patch, but 
it'd be nice in you mailed us and mentioned that you are.

Availability
------------
The latest version of this patch can always be found at the 
TeamFortress WWW page:
	http://minyos.its.rmit.edu.au/~cookj/index.htm

The latest version should also be on the following locations:
	ftp.cdrom.com/pub/quake/	<- check incoming, newstuff or quakec/multiplayer
The Quake Stomping Grounds:
	http://www.stomped.com/files.shtml

TeamFortress Maps can be found on our www site, or in the directory:
	ftp://ftp.cdrom.com/pub/idgames2/levels/team_fortress/

Other Stuff
-----------
TeamFortress was written by Robin Walker and John Cook. Various other people
contributed ideas to it. I can't hope to list them all, but here's some of them:
	Ian Caughley, Peter Wilson, Jason Grant.

A special mention _must_ go to Alexandre Brouaux (brouauxa@micronet.fr),
who's been a fantastic help, not only with the actual coding, but also
with other problems. The Pyro class is a direct result of his help.

Some of the code for TeamFortress was influenced by other people's.
They are as follows:
	Both Flame Grenades and the Flamer were almost entirely written
	by Alexandre Brouaux (brouauxa@micronet.fr). Thanks Alexandre!
	Mirv Grenade code was influenced by Firewall code from Steve Bond (wedge@nuc.net)
	Pipebomb code was influenced by code from AsmodeusB (tazq@sos.on.ca)

Although we've never seen their code, these people are credited here
because they've got great ideas:
	Multiskin, from the first person to work it out, Dennis Noordsij (lnoordsi@inter.NL.net)

Also, thanks must go to the following people for their comments and suggestions:
	John Wolsch (john_w@bga.com)
	Thomas LULLIER (106110.1406@compuserve.com)
	Alexandre Brouaux (brouauxa@micronet.fr)
	Bas Olthoff (reboot@dsl.nl)
	Phil Sykes (phil@centrenet.co.uk)
	Serendip (an705819@anon.penet.fi)
	Frank O'Connor (FrankO@mail.Publix.com)
	Chi Tang (ctang@nucleus.com)
	Chris Etheridge (etherbi@castlegate.net)
	Kevin Cheng (chengn@stu.ca)
	Matt Cortes (link@alpha.pulsar.net)
	Mark Rosten (mark@barney.dungeon.com)
	Craig Daily (cadaily@usa.pipeline.com)
We wouldn't have got past 1.0, let alone the rest, if it wasn't 
for these guys/gals.

And finally, thanks must go to Mike Kaminski (LKKAM@msn.com), for pointing
out the stupidest mistake I've made for a while :)

What are we working on now?
Version 1.4 is going to be the big class jump:
	Spy, Assassin, Engineer
Also, we'll have simple 'bot code for people who don't have enough
players in their neighbourhood to have enough players on each team:
	SniperBot, SoldierBot, MedicBot, HeavyWeaponsBot, and Turrets.
And _most_ importantly, Someone is going to rewrite this file,
since its hopelessly out of date and unreadable.

I'm happy to help with any questions about the source you have.
One thing that we took pains to do was to make almost _everything_ #defined. 
You can 'tweak' 90% the game details just by editing the defs.qc

Finally, if you want to talk to me, or play me, I can usually be found
most nights of the week on quake1.mel.aone.net.au
I'll be happy to answer any questions, or talk over suggestions.

Robin. (Bro in Quake)
walker@netspace.net.au

=======
Version info for those that interested:
--------------------------------
Version 1.32 - Released 10/11/96
--------------------------------
Features added:
	- Nextlevel command.
		Players can use the "Nextlevel" command to cycle through the
		v1.3 FortressMaps and choose which one will be played when the
		current one ends.
	- Deathmatch 3 setting.
		When in deathmatch 3, players can choose the class they will
		respawn as.

Changes:
	- Removed all pre-impulses.
	  	We used these in LAN games and they're fine. But on the net,
	  	the lag can cause problems with them. So they're gone. We 
	  	have left in the pre-impulses for Detpacks and Scanners so
	  	players can still define their own time settings/energy levels.
	- Detpack setting changed.
	  	Instead of stopping you for 4 seconds when you set a detpack,
	  	now you have to hold down the Detpack-Set key for 4 seconds
	  	without moving, and you can stop and run at any time.
	 	The old method is still there if you want to use it instead.
	- Sniper Rifle changed.
		It takes a little longer to build up the damage now, so snap-shots
		won't kill so much. Aiming still builds up the damage.
		Also, the Sniper must stop moving before he can start to aim.
	- Team Color Checking
		Now it doesn't penalise the player in any way for changing colors,
		it just sets them back. Players with lag on servers would get 
		penalised before they're colors had been set when they joined a 
		team. :)

Bugs Removed:
	- Announcing of class choices when deathmatching.
	- Sniper aiming not incrementing damage.
	- Teamfrags not keeping correct count.
	- Team 4 wasn't working.

--------------------------------
Version 1.31 - Released 4/11/96
--------------------------------
Features added:
	- Class choices are announced to Team Members.

Changes:
	- Pyro Class made a little weaker, as follows:
		- Flames on Players burn for half as long.
		- Incendiary Cannon has a smaller radius.

Bugs Removed:
	- Pipebomb's crashing the server.
		"I just commented out the debug!" John cried :)
	- Grenade names in inventory fixed.
	- Updating of Current Ammo fixed.
	- Weapon firing in air fixed.
		"Who the hell is DeMorgan?!?!" Robin screams :)
	- Speed resetting when a GoalItem is removed corrected.
	- Detpack activation of Goals fixed.

--------------------------------
Version 1.3  - Released 31/10/96
--------------------------------
Features added:
	- Lives for players in each team.
	- More Toggleables added.
		- TeamFrags
		- Server Only
	- Napalm Grenades added
	- Others, but I can't remember them. :)

Changes:
	- Entire TeamFortress Map code rewritten.
	  Huge amount of changes and added functionality for them.
	  See the tfortmap.txt for complete details.

Classes: Scout, Sniper, Soldier, Demolitions Man, Combat Medic,
		 Heavy Weapons Guy, Pyro, RandomClass.

Bugs Removed:
	- Respawn Delays fixed.
	- Inventory display of second Grenade type fixed.
	- Lotsa other small things

--------------------------------
Version 1.21 - Released 17/9/96
--------------------------------
Bugs Removed:
	- Assault Cannon backpack/cooling bug fixed.
	- BioWeapon not infecting monsters bug fixed.
	- Megahealth always curing infection bug fixed.
	- Detpack stuffcmd failure bug fixed.
	- Medikit non-precached sound bug fixed.
	- Deathmatch Everyone-respawn-in-the-same-place bug fixed.
	- Heavy Weapon Guy's weapons cleaned up.

--------------------------------
Version 1.2	- Released 11/9/96
--------------------------------
Features added:
	- TeamFortressMap Goal Support (Yeeha!)
	- Bioweapon for the Combat Medic
	- More Toggleables added.
		- Auto Teaming
		- Respawn Delays
	- Players start in Observer mode.

Classes: Scout, Sniper, Soldier, Demolitions Man, Combat Medic,
		 Heavy Weapons Guy, RandomClass.

Changes:
	- Rewrote various sections to reduce variable use
	- Changed Team Spawnpoints handling
	- Team Members now only damage each other with Area-Effect weapons.
	- Armor doesn't protect against drowning, etc.
	- Remove telefragging.
	- Concussion grenade toned down a little.
	- Rewrote all the code for timers. Not only does it
	  now save variable space, it also makes sure we clean
	  up _all_ timers.

Bugs Removed:
	- John got it! The nastiest bug we've had yet!! Bye bye Zmalloc error!
	- Medikit bug fixed
	- Toggleflags being incorrectly passed between levels fixed

Known Bugs:
	- The Assault Cannon cooling still isn't perfect.

--------------------------------
Version 1.1	- Released 31/8/96
--------------------------------
Features added:
	- Help revamped.
	- Aliases for Help, Detpacks, and Scanners added.
	- Multiple Player skin support added.
	- Added World Toggleables handling.
		- Classkin and Multiskin Toggle added.
		- Class persistence between levels Toggle added.
		- Cheatchecking Toggle added.
        - TeamFortressMap Toggle added.
	- Detpack CountDown added.
	- Scanner now gives directions of blips
	- NetServer setting which uses no non-standard quake files
	- TeamFortress Map Support (Yeah!!)

Classes: Scout, Sniper, Soldier, Demolitions Man, Combat Medic,
		 Heavy Weapons Guy.

Changes:
	- Undefined players are now invincible, but can't move.

Bugs Removed:
	- Detpack was spawning two objects.
	- Gibbed while Reloading bug fixed.
	- Dying while concussed bug fixed.

--------------------------------
Version 1.1	- Released 24/8/96
--------------------------------
Initial Release
Classes: Scout, Sniper, Soldier, Demolitions Man, Combat Medic
